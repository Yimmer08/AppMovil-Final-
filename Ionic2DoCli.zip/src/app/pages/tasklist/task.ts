export class Task {
    title: string | null;
    status: string;

    constructor() {
        this.title = "";
        this.status = "";
    }
}